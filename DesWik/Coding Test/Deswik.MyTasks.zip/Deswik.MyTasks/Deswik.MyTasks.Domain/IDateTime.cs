﻿using System;

namespace Deswik.MyTasks.Domain
{
    public interface IDateTime
    {
        DateTime Today { get; }
    }
}